package com.christian.displaydimmer

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.hardware.display.DisplayManager
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat

/**
 * Keeps a DimPresentation alive on the external ("desktop mode") display
 * for as long as the user wants dimming active. Runs as a foreground
 * service so Android doesn't kill it while the app itself is backgrounded
 * (which is the normal state once you're working on the external screen).
 */
class DimOverlayService : Service() {

    private var presentation: DimPresentation? = null
    private lateinit var displayManager: DisplayManager

    private val displayListener = object : DisplayManager.DisplayListener {
        override fun onDisplayAdded(displayId: Int) {
            attachToExternalDisplayIfAvailable()
        }

        override fun onDisplayRemoved(displayId: Int) {
            // If our display went away (cable unplugged / desktop mode
            // exited), drop the presentation so we don't hold a dead window.
            if (presentation?.display?.displayId == displayId) {
                presentation?.dismiss()
                presentation = null
            }
        }

        override fun onDisplayChanged(displayId: Int) {}
    }

    override fun onCreate() {
        super.onCreate()
        displayManager = getSystemService(DISPLAY_SERVICE) as DisplayManager
        displayManager.registerDisplayListener(displayListener, null)
        startForeground(NOTIFICATION_ID, buildNotification())
        attachToExternalDisplayIfAvailable()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_SET_LEVEL -> {
                val level = intent.getIntExtra(EXTRA_LEVEL, DimPresentation.currentAlpha)
                presentation?.setDimLevel(level) ?: run {
                    // No presentation yet (external display not found at
                    // launch time) - just remember the level for next attach.
                    DimPresentation.currentAlpha = level
                }
            }
            ACTION_STOP -> {
                stopSelf()
            }
        }
        return START_STICKY
    }

    private fun attachToExternalDisplayIfAvailable() {
        if (presentation != null) return

        // DisplayManager.DISPLAY_CATEGORY_ALL_INCLUDING_DISABLED could be
        // used, but presentation displays are the ones actually meant for
        // secondary-screen content, which is exactly the desktop-mode
        // external monitor.
        val presentationDisplays =
            displayManager.getDisplays(DisplayManager.DISPLAY_CATEGORY_PRESENTATION)

        val target = presentationDisplays.firstOrNull()
            ?: displayManager.displays.firstOrNull { it.displayId != android.view.Display.DEFAULT_DISPLAY }

        if (target != null) {
            presentation = DimPresentation(this, target).also {
                it.show()
                it.setDimLevel(DimPresentation.currentAlpha)
            }
        }
    }

    private fun buildNotification(): Notification {
        val channelId = "dim_overlay_channel"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = getSystemService(NotificationManager::class.java)
            val channel = NotificationChannel(
                channelId,
                getString(R.string.notification_channel_name),
                NotificationManager.IMPORTANCE_LOW
            )
            manager.createNotificationChannel(channel)
        }

        return NotificationCompat.Builder(this, channelId)
            .setContentTitle(getString(R.string.app_name))
            .setContentText(getString(R.string.notification_text))
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setOngoing(true)
            .build()
    }

    override fun onDestroy() {
        displayManager.unregisterDisplayListener(displayListener)
        presentation?.dismiss()
        presentation = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val ACTION_SET_LEVEL = "com.christian.displaydimmer.SET_LEVEL"
        const val ACTION_STOP = "com.christian.displaydimmer.STOP"
        const val EXTRA_LEVEL = "level"
        private const val NOTIFICATION_ID = 1001
    }
}
