package com.christian.displaydimmer

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.SeekBar
import androidx.appcompat.app.AppCompatActivity
import com.christian.displaydimmer.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.dimSeekBar.progress = DimPresentation.currentAlpha
        binding.dimValueText.text = "${DimPresentation.currentAlpha}%"

        binding.permissionButton.setOnClickListener { requestOverlayPermission() }

        binding.startButton.setOnClickListener {
            if (!hasOverlayPermission()) {
                requestOverlayPermission()
                return@setOnClickListener
            }
            val intent = Intent(this, DimOverlayService::class.java).apply {
                action = DimOverlayService.ACTION_SET_LEVEL
                putExtra(DimOverlayService.EXTRA_LEVEL, binding.dimSeekBar.progress)
            }
            startForegroundService(intent)
        }

        binding.stopButton.setOnClickListener {
            val intent = Intent(this, DimOverlayService::class.java).apply {
                action = DimOverlayService.ACTION_STOP
            }
            startService(intent)
        }

        binding.dimSeekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                binding.dimValueText.text = "$progress%"
                if (fromUser) {
                    val intent = Intent(this@MainActivity, DimOverlayService::class.java).apply {
                        action = DimOverlayService.ACTION_SET_LEVEL
                        putExtra(DimOverlayService.EXTRA_LEVEL, progress)
                    }
                    // Only push live updates if the service is presumably
                    // already running; harmless no-op otherwise since the
                    // service checks currentAlpha on next attach either way.
                    startService(intent)
                }
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
    }

    override fun onResume() {
        super.onResume()
        updatePermissionStatus()
    }

    private fun updatePermissionStatus() {
        val granted = hasOverlayPermission()
        binding.statusText.setText(
            if (granted) R.string.status_granted else R.string.status_not_granted
        )
        binding.permissionButton.isEnabled = !granted
    }

    private fun hasOverlayPermission(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Settings.canDrawOverlays(this)
        } else {
            true
        }
    }

    private fun requestOverlayPermission() {
        val intent = Intent(
            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
            Uri.parse("package:$packageName")
        )
        startActivity(intent)
    }
}
