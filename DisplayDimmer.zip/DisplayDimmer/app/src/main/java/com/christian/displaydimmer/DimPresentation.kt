package com.christian.displaydimmer

import android.app.Presentation
import android.content.Context
import android.graphics.Color
import android.os.Bundle
import android.view.Display
import android.view.Gravity
import android.view.WindowManager
import android.widget.FrameLayout

/**
 * A borderless, touch-transparent black view rendered directly onto the
 * external display (the "desktop mode" screen), stacked in the Presentation
 * window layer so it sits above whatever app is currently shown there.
 *
 * Presentation is the API Android provides specifically for secondary
 * displays - it automatically targets the given Display instead of the
 * device's built-in screen, which is what regular SYSTEM_ALERT_WINDOW
 * overlays fail to do in extended-display mode.
 */
class DimPresentation(
    outerContext: Context,
    display: Display
) : Presentation(outerContext, display) {

    private lateinit var dimView: FrameLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Let touches pass through to whatever is underneath - this is a
        // visual filter only, not an input blocker.
        window?.addFlags(
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
        )

        dimView = FrameLayout(context).apply {
            setBackgroundColor(Color.BLACK)
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            )
        }

        val root = FrameLayout(context)
        root.addView(dimView)
        setContentView(root)

        setAlpha(currentAlpha)
    }

    /**
     * @param alphaPercent 0..100, where 0 = fully transparent (no dimming)
     * and 100 = fully opaque black.
     */
    fun setDimLevel(alphaPercent: Int) {
        currentAlpha = alphaPercent.coerceIn(0, 100)
        if (::dimView.isInitialized) {
            setAlpha(currentAlpha)
        }
    }

    private fun setAlpha(percent: Int) {
        val alpha255 = (percent / 100f * 255).toInt().coerceIn(0, 255)
        dimView.background.alpha = alpha255
    }

    companion object {
        // Retained across recreation so a restarted Presentation picks up
        // the last level the user set.
        var currentAlpha: Int = 40
    }
}
