# Display Dimmer

App Android (Kotlin) que desenha um overlay preto semi-transparente diretamente
na tela **externa** (o display do modo desktop/Ready For da Motorola), com
brilho ajustável abaixo do mínimo do monitor.

## Por que isso funciona quando outros apps não funcionaram

Apps de overlay comuns (Screen Filter, Night Screen, etc.) usam
`SYSTEM_ALERT_WINDOW` sobre o display padrão (`Display.DEFAULT_DISPLAY`), que
é sempre a tela do celular. Em modo **extend display**, o monitor externo é um
`Display` totalmente separado, e esses apps nunca desenham nele.

Este app usa a classe `Presentation` do Android — a API oficial para
renderizar conteúdo em displays secundários — e o `DisplayManager` para
localizar o display externo especificamente, contornando essa limitação.

## Estrutura do projeto

```
DisplayDimmer/
├── app/
│   ├── build.gradle.kts
│   └── src/main/
│       ├── AndroidManifest.xml
│       ├── java/com/christian/displaydimmer/
│       │   ├── MainActivity.kt       -> tela de controle (slider + start/stop)
│       │   ├── DimOverlayService.kt  -> foreground service, localiza o display externo
│       │   └── DimPresentation.kt    -> a view preta desenhada no display externo
│       └── res/
├── build.gradle.kts
└── settings.gradle.kts
```

## Como compilar

1. Abra a pasta `DisplayDimmer/` no Android Studio (Giraffe ou mais recente).
2. Deixe o Gradle sincronizar (baixa as dependências automaticamente).
3. Conecte o celular via USB com depuração habilitada, ou gere um APK:
   `Build > Build Bundle(s) / APK(s) > Build APK(s)`.
4. Instale o APK no celular (ou rode direto pelo Android Studio).

Não precisa de conta de desenvolvedor nem de publicar na Play Store — é só
instalar como app pessoal (pode ser preciso permitir "instalar de fontes
desconhecidas" se for instalar o APK manualmente).

## Como usar

1. Abra o app **com o modo desktop já ativo** (monitor conectado, em modo
   extend, não espelhado).
2. Toque em **"Grant Display over other apps permission"** e conceda a
   permissão nas configurações do Android.
3. Ajuste o slider **Dim level** (0% = sem escurecimento, 100% = preto total).
4. Toque em **Start dimming external display**.
5. O overlay preto aparece por cima de tudo na tela externa, sem bloquear
   toque nem interação — é só um filtro visual.
6. Para parar, volte ao app e toque em **Stop dimming**, ou derrube a
   notificação persistente do serviço.

O slider atualiza o overlay em tempo real enquanto o serviço estiver rodando.

## Limitações conhecidas / pontos de atenção

- **Se o app for aberto antes do modo desktop ser ativado**, o serviço ainda
  assim tenta detectar o display quando ele aparece (via
  `DisplayListener.onDisplayAdded`), então normalmente não precisa reabrir o
  app — mas se não pegar automaticamente, feche e abra o app de novo com o
  monitor já conectado.
- **Captura de tela/gravação da tela externa** vai mostrar o overlay aplicado
  (é uma camada real de renderização, não um truque só visual pro olho).
- **Android 14+ (foreground service types)**: o manifest já declara
  `specialUse` como tipo do serviço, que é o correto para esse caso de uso;
  isso é obrigatório a partir do Android 14 para foreground services que não
  se encaixam nas categorias padrão (mídia, localização, etc).
- Se o fabricante (Motorola) tiver otimizações agressivas de bateria, pode
  ser necessário desativar a otimização de bateria para este app
  (Configurações > Apps > Display Dimmer > Bateria > Sem restrições), senão o
  Android pode matar o serviço depois de um tempo.
- O código assume um único display externo. Se você algum dia conectar dois
  monitores simultâneos, `attachToExternalDisplayIfAvailable()` pega o
  primeiro da lista — dá pra estender depois se precisar.

## Próximos passos possíveis

- Quick Settings Tile para ligar/desligar sem abrir o app.
- Salvar o nível de dimming escolhido em `SharedPreferences` para persistir
  entre reinicializações do app (hoje ele já persiste durante a sessão via
  companion object, mas não sobrevive a um kill completo do processo).
- Detectar automaticamente quando o modo desktop é ativado e iniciar o
  dimming sozinho, sem precisar abrir o app manualmente.
